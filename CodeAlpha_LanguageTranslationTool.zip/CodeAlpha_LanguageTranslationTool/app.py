import tkinter as tk
from tkinter import ttk, messagebox
from translator import translate_text, TranslationError

LANGUAGES = {
    "Auto Detect": "auto",
    "English": "en",
    "Urdu": "ur",
    "Arabic": "ar",
    "French": "fr",
    "German": "de",
    "Spanish": "es",
    "Italian": "it",
    "Portuguese": "pt",
    "Russian": "ru",
    "Chinese": "zh",
    "Japanese": "ja",
    "Korean": "ko",
    "Hindi": "hi",
    "Turkish": "tr",
    "Bengali": "bn"
}


class TranslationApp:

    def __init__(self, root):
        self.root = root
        self.root.title("CodeAlpha - AI Language Translation Tool")
        self.root.geometry("1000x650")
        self.root.minsize(850, 600)
        self.build()

    def build(self):

        main = ttk.Frame(self.root, padding=20)
        main.pack(fill="both", expand=True)

        ttk.Label(
            main,
            text="AI Language Translation Tool",
            font=("Segoe UI", 24, "bold")
        ).pack(pady=(0, 5))

        ttk.Label(
            main,
            text="Translate text between multiple languages",
            font=("Segoe UI", 11)
        ).pack(pady=(0, 10))


        language_frame = ttk.Frame(main)
        language_frame.pack(fill="x", pady=5)

        ttk.Label(
            language_frame,
            text="Source Language",
            font=("Segoe UI", 11, "bold")
        ).grid(row=0, column=0, sticky="w", padx=5)

        ttk.Label(
            language_frame,
            text="Target Language",
            font=("Segoe UI", 11, "bold")
        ).grid(row=0, column=2, sticky="w", padx=5)


        self.source = tk.StringVar(value="Auto Detect")
        self.target = tk.StringVar(value="Urdu")


        ttk.Combobox(
            language_frame,
            textvariable=self.source,
            values=list(LANGUAGES.keys()),
            state="readonly"
        ).grid(row=1, column=0, sticky="ew", padx=5, pady=5)


        ttk.Button(
            language_frame,
            text="⇄",
            command=self.swap,
            width=5
        ).grid(row=1, column=1, padx=10)


        target_languages = [
            language for language in LANGUAGES
            if language != "Auto Detect"
        ]


        ttk.Combobox(
            language_frame,
            textvariable=self.target,
            values=target_languages,
            state="readonly"
        ).grid(row=1, column=2, sticky="ew", padx=5, pady=5)


        language_frame.columnconfigure(0, weight=1)
        language_frame.columnconfigure(2, weight=1)


        button_frame = tk.Frame(main)
        button_frame.pack(fill="x", pady=8)


        tk.Button(
            button_frame,
            text="TRANSLATE",
            command=self.translate,
            font=("Segoe UI", 11, "bold"),
            bg="#2563EB",
            fg="white",
            activebackground="#1D4ED8",
            activeforeground="white",
            padx=25,
            pady=10,
            relief="raised",
            bd=2,
            cursor="hand2"
        ).pack(side="left", padx=5)


        tk.Button(
            button_frame,
            text="COPY TRANSLATION",
            command=self.copy_translation,
            font=("Segoe UI", 10, "bold"),
            padx=18,
            pady=9,
            relief="raised",
            bd=2,
            cursor="hand2"
        ).pack(side="left", padx=5)


        tk.Button(
            button_frame,
            text="CLEAR",
            command=self.clear,
            font=("Segoe UI", 10, "bold"),
            padx=18,
            pady=9,
            relief="raised",
            bd=2,
            cursor="hand2"
        ).pack(side="left", padx=5)


        self.status = tk.StringVar(value="Ready")


        ttk.Label(
            main,
            textvariable=self.status,
            font=("Segoe UI", 9)
        ).pack(anchor="w", pady=3)


        text_frame = ttk.Frame(main)
        text_frame.pack(
            fill="both",
            expand=True,
            pady=5
        )


        left_frame = ttk.Frame(text_frame)
        left_frame.pack(
            side="left",
            fill="both",
            expand=True,
            padx=(0, 8)
        )


        right_frame = ttk.Frame(text_frame)
        right_frame.pack(
            side="right",
            fill="both",
            expand=True,
            padx=(8, 0)
        )


        ttk.Label(
            left_frame,
            text="Input Text",
            font=("Segoe UI", 11, "bold")
        ).pack(anchor="w", pady=(0, 5))


        self.input_text = tk.Text(
            left_frame,
            wrap="word",
            font=("Segoe UI", 12),
            padx=10,
            pady=10
        )

        self.input_text.pack(
            fill="both",
            expand=True
        )


        self.input_text.bind(
            "<KeyRelease>",
            self.update_character_count
        )


        self.character_label = ttk.Label(
            left_frame,
            text="0 characters"
        )

        self.character_label.pack(
            anchor="e",
            pady=3
        )


        ttk.Label(
            right_frame,
            text="Translated Text",
            font=("Segoe UI", 11, "bold")
        ).pack(anchor="w", pady=(0, 5))


        self.output_text = tk.Text(
            right_frame,
            wrap="word",
            font=("Segoe UI", 12),
            padx=10,
            pady=10,
            state="disabled"
        )

        self.output_text.pack(
            fill="both",
            expand=True
        )


    def translate(self):

        text = self.input_text.get(
            "1.0",
            tk.END
        ).strip()


        if not text:

            messagebox.showwarning(
                "Empty Input",
                "Please enter some text before translating."
            )

            return


        source = LANGUAGES[
            self.source.get()
        ]

        target = LANGUAGES[
            self.target.get()
        ]


        if source != "auto" and source == target:

            messagebox.showwarning(
                "Same Language",
                "Please select different source and target languages."
            )

            return


        try:

            self.status.set(
                "Translating..."
            )

            self.root.update_idletasks()


            result = translate_text(
                text,
                source,
                target
            )


            self.output_text.config(
                state="normal"
            )


            self.output_text.delete(
                "1.0",
                tk.END
            )


            self.output_text.insert(
                "1.0",
                result
            )


            self.output_text.config(
                state="disabled"
            )


            self.status.set(
                "Translation completed successfully."
            )


        except TranslationError as error:

            self.status.set(
                "Translation failed."
            )

            messagebox.showerror(
                "Translation Error",
                str(error)
            )


        except Exception as error:

            self.status.set(
                "Unexpected error occurred."
            )

            messagebox.showerror(
                "Error",
                f"An unexpected error occurred:\n\n{error}"
            )


    def copy_translation(self):

        self.output_text.config(
            state="normal"
        )


        text = self.output_text.get(
            "1.0",
            tk.END
        ).strip()


        self.output_text.config(
            state="disabled"
        )


        if not text:

            messagebox.showwarning(
                "Nothing to Copy",
                "There is no translated text to copy."
            )

            return


        self.root.clipboard_clear()

        self.root.clipboard_append(
            text
        )

        self.root.update()


        self.status.set(
            "Translation copied to clipboard."
        )


    def clear(self):

        self.input_text.delete(
            "1.0",
            tk.END
        )


        self.output_text.config(
            state="normal"
        )


        self.output_text.delete(
            "1.0",
            tk.END
        )


        self.output_text.config(
            state="disabled"
        )


        self.source.set(
            "Auto Detect"
        )


        self.target.set(
            "Urdu"
        )


        self.status.set(
            "Ready"
        )


        self.update_character_count()


    def swap(self):

        source = self.source.get()
        target = self.target.get()


        if source == "Auto Detect":

            source = "English"


        input_text = self.input_text.get(
            "1.0",
            tk.END
        ).strip()


        output_text = self.output_text.get(
            "1.0",
            tk.END
        ).strip()


        self.source.set(
            target
        )


        self.target.set(
            source
        )


        self.input_text.delete(
            "1.0",
            tk.END
        )


        self.input_text.insert(
            "1.0",
            output_text
        )


        self.output_text.config(
            state="normal"
        )


        self.output_text.delete(
            "1.0",
            tk.END
        )


        self.output_text.insert(
            "1.0",
            input_text
        )


        self.output_text.config(
            state="disabled"
        )


        self.update_character_count()


    def update_character_count(
        self,
        event=None
    ):

        text = self.input_text.get(
            "1.0",
            tk.END
        ).strip()


        self.character_label.config(
            text=f"{len(text)} characters"
        )


if __name__ == "__main__":

    root = tk.Tk()

    app = TranslationApp(
        root
    )

    root.mainloop()