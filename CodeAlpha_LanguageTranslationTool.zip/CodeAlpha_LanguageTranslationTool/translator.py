import requests

class TranslationError(Exception):
    pass


LANGUAGE_CODES = {
    "Auto Detect": "auto",
    "English": "en",
    "Urdu": "ur",
    "Sindhi": "sd",
    "Arabic": "ar",
    "French": "fr",
    "German": "de",
    "Spanish": "es",
    "Italian": "it",
    "Portuguese": "pt",
    "Russian": "ru",
    "Chinese": "zh",
    "Japanese": "ja",
    "Korean": "ko",
    "Hindi": "hi",
    "Turkish": "tr",
    "Bengali": "bn"
}


LIBRETRANSLATE_URL = "http://localhost:5000"


def get_language_code(language):
    if not language:
        raise TranslationError("Please select a language.")

    language = language.strip()

    if language in LANGUAGE_CODES:
        return LANGUAGE_CODES[language]

    language_lower = language.lower()

    for name, code in LANGUAGE_CODES.items():
        if name.lower() == language_lower:
            return code

    if language_lower == "zh-cn":
        return "zh"

    if language_lower in LANGUAGE_CODES.values():
        return language_lower

    raise TranslationError(f"Unsupported language: {language}")


def detect_language(text):
    try:
        response = requests.post(
            f"{LIBRETRANSLATE_URL}/detect",
            json={"q": text},
            timeout=60
        )

        if response.status_code != 200:
            raise TranslationError(
                f"Language detection failed: {response.status_code}"
            )

        data = response.json()

        if not data:
            raise TranslationError("Could not detect the language.")

        detected_language = data[0].get("language")

        if not detected_language:
            raise TranslationError("Could not detect the language.")

        return detected_language

    except requests.ConnectionError:
        raise TranslationError(
            "LibreTranslate is not running. Please start the LibreTranslate server."
        )

    except requests.Timeout:
        raise TranslationError("Language detection timed out.")

    except requests.RequestException as error:
        raise TranslationError(f"Connection error: {error}")

    except ValueError:
        raise TranslationError("Invalid response from LibreTranslate.")


def translate_text(text, source_language, target_language):
    if not text or not text.strip():
        raise TranslationError("Please enter text to translate.")

    source_code = get_language_code(source_language)
    target_code = get_language_code(target_language)

    if target_code == "auto":
        raise TranslationError(
            "Auto Detect cannot be used as the target language."
        )

    if source_code == "auto":
        source_code = detect_language(text)

    if source_code == target_code:
        return text.strip()

    payload = {
        "q": text.strip(),
        "source": source_code,
        "target": target_code,
        "format": "text"
    }

    try:
        response = requests.post(
            f"{LIBRETRANSLATE_URL}/translate",
            json=payload,
            timeout=60
        )

        if response.status_code != 200:
            try:
                error_data = response.json()
                error_message = error_data.get("error", response.text)
            except ValueError:
                error_message = response.text

            raise TranslationError(
                f"LibreTranslate error ({response.status_code}): {error_message}"
            )

        data = response.json()

        translated_text = data.get("translatedText")

        if not translated_text:
            raise TranslationError(
                "LibreTranslate did not return translated text."
            )

        return translated_text

    except requests.ConnectionError:
        raise TranslationError(
            "LibreTranslate is not running. Please start the LibreTranslate server."
        )

    except requests.Timeout:
        raise TranslationError(
            "Translation request timed out."
        )

    except requests.RequestException as error:
        raise TranslationError(
            f"Translation service error: {error}"
        )

    except ValueError:
        raise TranslationError(
            "LibreTranslate returned invalid data."
        )